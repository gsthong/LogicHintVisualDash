from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
import json

from app.db.database import get_db
from app.models import User, Problem, HintUsage, TestCase
from app.core.security import get_current_user, require_admin
from app.services import ai_service
from app.services.static_analyzer import full_analyze
from app.services.ocr_service import (
    image_to_problem_json,
    pdf_to_problem_json,
    text_to_problem_json,
    generate_testcase_script,
    generate_testcases_from_problem,
)

router = APIRouter(prefix="/api/ai", tags=["ai"])

class HintRequest(BaseModel):
    problem_id: int
    code: str = ""
    hint_level: int = 1

class BugRequest(BaseModel):
    code: str
    language: str
    error_message: str = ""
    problem_id: Optional[int] = None

class FlowchartRequest(BaseModel):
    code: str
    language: str

class ComplexityRequest(BaseModel):
    code: str
    language: str

class StaticAnalyzeRequest(BaseModel):
    code: str
    language: str = "cpp"

class ProblemTextRequest(BaseModel):
    text: str

class GenerateTestcasesRequest(BaseModel):
    problem_id: int


@router.post("/hint")
def get_hint(req: HintRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    problem = db.query(Problem).filter(Problem.id == req.problem_id).first()
    if not problem:
        raise HTTPException(404, "Problem not found")
    usage = HintUsage(user_id=current_user.id, problem_id=req.problem_id, hint_level=req.hint_level)
    db.add(usage); db.commit()
    prev = db.query(HintUsage).filter(
        HintUsage.user_id == current_user.id,
        HintUsage.problem_id == req.problem_id,
        HintUsage.hint_level < req.hint_level,
    ).all()
    hint = ai_service.get_hint(problem.description, req.code, req.hint_level,
                               [{"level": u.hint_level, "content": ""} for u in prev])
    return {"hint": hint, "level": req.hint_level}


@router.post("/static-analyze")
def static_analyze(req: StaticAnalyzeRequest, _: User = Depends(get_current_user)):
    """GNN-derived heuristic: TLE risk, hints, bugs, skill profile. No API key needed."""
    if not req.code.strip():
        raise HTTPException(400, "Empty code")
    return full_analyze(req.code, req.language)


@router.post("/analyze-bugs")
def analyze_bugs(req: BugRequest, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    """Static + Groq LLM bug analysis combined."""
    problem_desc = ""
    if req.problem_id:
        p = db.query(Problem).filter(Problem.id == req.problem_id).first()
        if p: problem_desc = p.description
    static = full_analyze(req.code, req.language)
    llm_result = ai_service.analyze_bugs(req.code, req.language, req.error_message, problem_desc)
    seen, merged = set(), []
    for b in static.get("bugs", []) + llm_result.get("bugs", []):
        key = (b.get("type"), b.get("line"))
        if key not in seen:
            seen.add(key); merged.append(b)
    return {"bugs": merged, "summary": llm_result.get("summary", ""),
            "tle_risk": static.get("tle_risk", 0), "tle_label": static.get("tle_label", "")}


@router.post("/flowchart")
def generate_flowchart(req: FlowchartRequest, _: User = Depends(get_current_user)):
    return {"mermaid": ai_service.generate_flowchart(req.code, req.language)}


@router.post("/complexity")
def analyze_complexity(req: ComplexityRequest, _: User = Depends(get_current_user)):
    return ai_service.analyze_complexity(req.code, req.language)


@router.post("/ocr/image")
async def ocr_image(file: UploadFile = File(...), _: User = Depends(get_current_user)):
    """Ảnh đề bài → Gemini Vision → JSON. Fallback: EasyOCR + Groq."""
    content = await file.read()
    mime = "image/png" if file.filename.lower().endswith(".png") else "image/jpeg"
    result = image_to_problem_json(content, mime)
    return {"problem": result}


@router.post("/ocr/pdf")
async def ocr_pdf(file: UploadFile = File(...), _: User = Depends(get_current_user)):
    """PDF đề bài → pdfplumber/EasyOCR + Groq → JSON."""
    content = await file.read()
    result = pdf_to_problem_json(content)
    return {"problem": result}


@router.post("/ocr/image-to-testcases")
async def ocr_image_to_testcases(
    file: UploadFile = File(...),
    save_to_problem_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Ảnh đề bài → Gemini Vision → JSON → sinh testcases tự động + Python script."""
    content = await file.read()
    mime = "image/png" if file.filename.lower().endswith(".png") else "image/jpeg"
    problem_json = image_to_problem_json(content, mime)
    testcases = generate_testcases_from_problem(problem_json)
    saved = 0
    if save_to_problem_id:
        p = db.query(Problem).filter(Problem.id == save_to_problem_id).first()
        if p:
            for i, tc in enumerate(testcases):
                db.add(TestCase(problem_id=p.id, input=tc.get("input",""),
                                expected_output=tc.get("expected_output",""),
                                is_hidden=True, order=200+i))
            db.commit(); saved = len(testcases)
    script = generate_testcase_script(problem_json)
    return {"problem": problem_json, "testcases": testcases,
            "testcase_count": len(testcases), "saved_to_db": saved, "generator_script": script}


@router.post("/ocr/pdf-to-testcases")
async def ocr_pdf_to_testcases(
    file: UploadFile = File(...),
    save_to_problem_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """PDF đề bài → testcases tự động."""
    content = await file.read()
    problem_json = pdf_to_problem_json(content)
    testcases = generate_testcases_from_problem(problem_json)
    saved = 0
    if save_to_problem_id:
        p = db.query(Problem).filter(Problem.id == save_to_problem_id).first()
        if p:
            for i, tc in enumerate(testcases):
                db.add(TestCase(problem_id=p.id, input=tc.get("input",""),
                                expected_output=tc.get("expected_output",""),
                                is_hidden=True, order=200+i))
            db.commit(); saved = len(testcases)
    return {"problem": problem_json, "testcases": testcases,
            "testcase_count": len(testcases), "saved_to_db": saved,
            "generator_script": generate_testcase_script(problem_json)}


@router.post("/generate-testcases")
def generate_testcases_endpoint(req: GenerateTestcasesRequest, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    problem = db.query(Problem).filter(Problem.id == req.problem_id).first()
    if not problem: raise HTTPException(404, "Problem not found")
    tcs = generate_testcases_from_problem({"title": problem.title, "description": problem.description,
                                           "examples": problem.examples or [], "constraints": problem.constraints})
    for i, tc in enumerate(tcs):
        db.add(TestCase(problem_id=problem.id, input=tc.get("input",""),
                        expected_output=tc.get("expected_output",""), is_hidden=True, order=100+i))
    db.commit()
    return {"created": len(tcs), "testcases": tcs}


@router.post("/parse-problem")
def parse_problem(req: ProblemTextRequest, _: User = Depends(get_current_user)):
    return text_to_problem_json(req.text)


@router.post("/upload-syllabus")
async def upload_syllabus(file: UploadFile = File(...), db: Session = Depends(get_db),
                          current_user: User = Depends(get_current_user)):
    content = await file.read()
    if file.filename.lower().endswith(".pdf"):
        from app.services.ocr_service import extract_text_from_pdf
        text = extract_text_from_pdf(content)
    else:
        text = content.decode("utf-8", errors="replace")
    topics = ai_service.parse_syllabus(text)
    from app.models import Syllabus
    db.add(Syllabus(user_id=current_user.id, filename=file.filename, topics=topics, raw_text=text[:5000]))
    db.commit()
    return {"topics": topics, "filename": file.filename}
