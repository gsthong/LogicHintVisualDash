import asyncio
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.db.database import get_db
from app.models import Submission, Problem, TestCase, SkillProfile, User
from app.core.security import get_current_user
from app.services.judge import run_code
from app.services.ai_service import analyze_complexity, explain_success

router = APIRouter(prefix="/api/submissions", tags=["submissions"])


class SubmitRequest(BaseModel):
    problem_id: int
    code: str
    language: str  # cpp | python

class RunRequest(BaseModel):
    code: str
    language: str
    stdin: str
    time_limit: float = 5.0

class SubmissionResponse(BaseModel):
    id: int
    problem_id: int
    status: str
    tests_passed: int
    tests_total: int
    runtime_ms: Optional[float]
    error_message: Optional[str]
    time_complexity: Optional[str]
    space_complexity: Optional[str]
    submitted_at: datetime
    class Config:
        from_attributes = True


@router.post("/run")
async def run_code_endpoint(req: RunRequest, _: User = Depends(get_current_user)):
    """Quick run — no submission, just execute against custom input"""
    result = await run_code(req.language, req.code, req.stdin, req.time_limit)
    return result


@router.post("", response_model=SubmissionResponse, status_code=201)
async def submit(req: SubmitRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    problem = db.query(Problem).filter(Problem.id == req.problem_id).first()
    if not problem:
        raise HTTPException(404, "Problem not found")

    testcases = db.query(TestCase).filter(TestCase.problem_id == req.problem_id).order_by(TestCase.order).all()
    if not testcases:
        raise HTTPException(400, "No testcases available for this problem")

    submission = Submission(
        user_id=current_user.id,
        problem_id=req.problem_id,
        code=req.code,
        language=req.language,
        status="pending",
        tests_total=len(testcases),
    )
    db.add(submission)
    db.commit()

    # Judge all testcases
    passed = 0
    final_status = "AC"
    error_msg = None

    for tc in testcases:
        result = await run_code(req.language, req.code, tc.input, problem.time_limit)

        if result["status"] == "CE":
            final_status = "CE"
            error_msg = result.get("error", "")[:1000]
            break
        elif result["status"] == "TLE":
            final_status = "TLE"
            error_msg = "Time limit exceeded"
            break
        elif result["status"] == "RE":
            final_status = "RE"
            error_msg = result.get("error", "")[:500]
            break
        elif result["status"] == "OK":
            actual   = result["output"].strip()
            expected = tc.expected_output.strip()
            if actual == expected:
                passed += 1
            else:
                final_status = "WA"
                error_msg = f"Test #{tc.order+1}: expected '{expected}', got '{actual}'"
                break

    # AI complexity analysis
    complexity = {"time_complexity": None, "space_complexity": None}
    if final_status == "AC":
        try:
            complexity = analyze_complexity(req.code, req.language)
        except Exception:
            pass
        # Update skill profile
        _update_skill(db, current_user.id, problem.syllabus_topic)

    # Update submission
    submission.status          = final_status
    submission.tests_passed    = passed
    submission.error_message   = error_msg
    submission.time_complexity = complexity.get("time_complexity")
    submission.space_complexity = complexity.get("space_complexity")
    db.commit()
    db.refresh(submission)
    return submission


@router.get("/me", response_model=List[SubmissionResponse])
def my_submissions(
    problem_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = db.query(Submission).filter(Submission.user_id == current_user.id)
    if problem_id:
        q = q.filter(Submission.problem_id == problem_id)
    return q.order_by(Submission.submitted_at.desc()).limit(50).all()


@router.get("/{submission_id}")
def get_submission(submission_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    s = db.query(Submission).filter(Submission.id == submission_id).first()
    if not s:
        raise HTTPException(404, "Not found")
    if s.user_id != current_user.id and current_user.role != "admin":
        raise HTTPException(403, "Forbidden")
    return s


@router.get("/{submission_id}/explain")
def explain_submission(submission_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    s = db.query(Submission).filter(Submission.id == submission_id, Submission.user_id == current_user.id).first()
    if not s or s.status != "AC":
        raise HTTPException(404, "Accepted submission not found")
    problem = db.query(Problem).filter(Problem.id == s.problem_id).first()
    explanation = explain_success(
        s.code, s.language, problem.description,
        s.time_complexity or "?", s.space_complexity or "?",
        problem.optimal_time_complexity or "?", problem.optimal_space_complexity or "?"
    )
    return {"explanation": explanation}


def _update_skill(db: Session, user_id: int, topic: Optional[str]):
    if not topic:
        return
    skill = db.query(SkillProfile).filter(
        SkillProfile.user_id == user_id, SkillProfile.topic == topic
    ).first()
    if not skill:
        skill = SkillProfile(user_id=user_id, topic=topic, proficiency=10, problems_solved=1)
        db.add(skill)
    else:
        skill.problems_solved += 1
        skill.proficiency = min(100, skill.proficiency + 5)
        skill.updated_at = datetime.utcnow()
    db.commit()
