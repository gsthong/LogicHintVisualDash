from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.db.database import get_db
from app.models import Problem, TestCase, Submission
from app.core.security import get_current_user, require_admin
from app.models import User

router = APIRouter(prefix="/api/problems", tags=["problems"])


class ProblemCreate(BaseModel):
    title: str
    description: str
    difficulty: str
    time_limit: float = 2.0
    memory_limit: int = 256
    tags: list = []
    syllabus_topic: Optional[str] = None
    constraints: Optional[str] = None
    examples: list = []
    optimal_time_complexity: Optional[str] = None
    optimal_space_complexity: Optional[str] = None

class ProblemResponse(BaseModel):
    id: int
    title: str
    description: str
    difficulty: str
    time_limit: float
    memory_limit: int
    tags: list
    syllabus_topic: Optional[str]
    constraints: Optional[str]
    examples: list
    optimal_time_complexity: Optional[str]
    optimal_space_complexity: Optional[str]
    source: str
    created_at: datetime
    class Config:
        from_attributes = True


@router.get("", response_model=List[ProblemResponse])
def list_problems(
    difficulty: Optional[str] = Query(None),
    topic: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    q = db.query(Problem)
    if difficulty:
        q = q.filter(Problem.difficulty == difficulty)
    if topic:
        q = q.filter(Problem.syllabus_topic == topic)
    if search:
        q = q.filter(Problem.title.ilike(f"%{search}%"))
    return q.offset(skip).limit(limit).all()


@router.get("/{problem_id}", response_model=ProblemResponse)
def get_problem(problem_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    p = db.query(Problem).filter(Problem.id == problem_id).first()
    if not p:
        raise HTTPException(404, "Problem not found")
    return p


@router.post("", response_model=ProblemResponse, status_code=201)
def create_problem(data: ProblemCreate, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    p = Problem(**data.dict())
    db.add(p)
    db.commit()
    db.refresh(p)
    return p


@router.put("/{problem_id}", response_model=ProblemResponse)
def update_problem(problem_id: int, data: ProblemCreate, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    p = db.query(Problem).filter(Problem.id == problem_id).first()
    if not p:
        raise HTTPException(404, "Problem not found")
    for k, v in data.dict().items():
        setattr(p, k, v)
    db.commit()
    db.refresh(p)
    return p


@router.delete("/{problem_id}")
def delete_problem(problem_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    p = db.query(Problem).filter(Problem.id == problem_id).first()
    if not p:
        raise HTTPException(404, "Not found")
    db.delete(p)
    db.commit()
    return {"message": "Deleted"}


@router.get("/{problem_id}/stats")
def problem_stats(problem_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    total = db.query(Submission).filter(Submission.problem_id == problem_id).count()
    accepted = db.query(Submission).filter(Submission.problem_id == problem_id, Submission.status == "AC").count()
    return {
        "total_submissions": total,
        "accepted": accepted,
        "acceptance_rate": round(accepted / total * 100, 1) if total else 0,
    }
