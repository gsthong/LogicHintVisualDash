'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Code2, BarChart3, FileText, Settings, BookOpen, Trophy } from 'lucide-react';
import { cn } from '@/lib/utils';

const navigationItems = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: BarChart3,
    description: 'View your progress'
  },
  {
    name: 'Practice',
    href: '/practice',
    icon: Code2,
    description: 'Solve problems'
  },
  {
    name: 'Mock Exams',
    href: '/mock-exams',
    icon: Trophy,
    description: 'Test yourself'
  },
  {
    name: 'Syllabus',
    href: '/syllabus-upload',
    icon: BookOpen,
    description: 'Upload & manage'
  },
  {
    name: 'Settings',
    href: '/settings',
    icon: Settings,
    description: 'Preferences'
  }
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col pt-8 z-40">
      {/* Logo */}
      <div className="px-6 mb-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-linear-to-br from-accent to-primary flex items-center justify-center shadow-lg shadow-primary/30">
            <Code2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-sidebar-foreground">CodeMentor</h1>
            <p className="text-xs text-sidebar-foreground/60">Learn to Code</p>
          </div>
        </div>
      </div>

      {/* Navigation Items */}
      <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname.startsWith(item.href);

          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 cursor-pointer group',
                  isActive
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-lg shadow-sidebar-primary/20'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent'
                )}
              >
                <Icon
                  className={cn(
                    'w-5 h-5 transition-transform duration-200',
                    isActive && 'group-hover:scale-110'
                  )}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{item.name}</p>
                  <p className={cn(
                    'text-xs truncate transition-opacity',
                    isActive ? 'text-sidebar-primary-foreground/70' : 'text-sidebar-foreground/50'
                  )}>
                    {item.description}
                  </p>
                </div>
                {isActive && (
                  <div className="w-1 h-6 bg-accent rounded-full" />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Footer Stats */}
      <div className="border-t border-sidebar-border p-4 space-y-3">
        <div className="bg-sidebar-accent rounded-lg p-3">
          <p className="text-xs text-sidebar-foreground/60 mb-1">Current Streak</p>
          <p className="text-2xl font-bold text-sidebar-primary">7 🔥</p>
        </div>
        <div className="bg-sidebar-accent rounded-lg p-3">
          <p className="text-xs text-sidebar-foreground/60 mb-1">Problems Solved</p>
          <p className="text-2xl font-bold text-sidebar-primary">24</p>
        </div>
      </div>
    </aside>
  );
}
