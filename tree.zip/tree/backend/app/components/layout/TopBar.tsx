'use client';

import { Bell, Zap, Download, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export function TopBar() {
  return (
    <header className="fixed top-0 left-64 right-0 h-16 bg-card border-b border-border flex items-center justify-between px-6 z-30">
      {/* Left Section - Search/Title */}
      <div className="flex-1 flex items-center">
        <h2 className="text-lg font-bold text-foreground">Practice Area</h2>
      </div>

      {/* Right Section - Status & Menu */}
      <div className="flex items-center gap-4">
        {/* Wecode Sync Status */}
        <div className="flex items-center gap-2 px-3 py-2 bg-secondary/20 border border-secondary/30 rounded-lg hover:border-secondary/60 transition-colors cursor-pointer group">
          <Zap className="w-4 h-4 text-yellow-500 group-hover:animate-pulse" />
          <span className="text-sm font-medium text-foreground">Last sync: 2h ago</span>
        </div>

        {/* Notifications */}
        <Button
          variant="ghost"
          size="icon"
          className="relative hover:bg-secondary"
        >
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
        </Button>

        {/* Profile Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="pl-2 pr-3 h-10 hover:bg-secondary">
              <Avatar className="w-6 h-6 mr-2">
                <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=CodeMentor" />
                <AvatarFallback>CM</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">You</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <div className="px-2 py-1.5">
              <p className="text-sm font-bold">Student Name</p>
              <p className="text-xs text-foreground/60">student@example.com</p>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer">
              <Download className="w-4 h-4 mr-2" />
              <span>Download Progress</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer text-destructive focus:text-destructive">
              <LogOut className="w-4 h-4 mr-2" />
              <span>Sign Out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
