'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Play, Send, Bug } from 'lucide-react';
import { toast } from 'sonner';
import { CODE_TEMPLATES, LANGUAGES } from '@/lib/constants';

type Language = 'python' | 'cpp' | 'java' | 'javascript';

export function CodeEditor() {
  const [code, setCode] = useState<string>(CODE_TEMPLATES.python);
  const [language, setLanguage] = useState<Language>('python');
  const [isRunning, setIsRunning] = useState(false);

  const handleLanguageChange = (newLang: Language) => {
    setLanguage(newLang);
    setCode(CODE_TEMPLATES[newLang]);
  };

  const handleRun = () => {
    setIsRunning(true);
    setTimeout(() => {
      setIsRunning(false);
      toast.success('Test ran successfully!', {
        description: '3/3 test cases passed'
      });
    }, 1500);
  };

  const handleSubmit = () => {
    setIsRunning(true);
    setTimeout(() => {
      setIsRunning(false);
      toast.success('Submitted to Wecode!', {
        description: 'Your solution will be evaluated'
      });
    }, 1500);
  };

  const handleDebug = () => {
    toast.info('Opening AI Debugger', {
      description: 'Let AI help you find the issue'
    });
  };

  return (
    <div className="h-full w-full flex flex-col bg-card border-r border-border overflow-hidden">
      {/* Header: Language Selector */}
      <div className="p-4 border-b border-border space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-sm font-bold text-foreground">Code Editor</p>
          <Select value={language} onValueChange={(v) => handleLanguageChange(v as Language)}>
            <SelectTrigger className="w-32 bg-background border-border text-foreground">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent className="bg-card border-border">
              {LANGUAGES.map(lang => (
                <SelectItem key={lang.value} value={lang.value} className="text-foreground">
                  {lang.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Info */}
        <div className="flex items-center gap-2 text-xs text-foreground/60 bg-background/50 px-2 py-1 rounded border border-border/50">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <span>Connected • Ready to Code</span>
        </div>
      </div>

      {/* Editor Textarea */}
      <div className="flex-1 overflow-hidden p-4 flex flex-col">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="flex-1 w-full bg-background border border-border rounded font-mono text-sm p-4 text-foreground/90 resize-none focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-transparent"
          spellCheck="false"
          placeholder="Write your code here..."
          style={{ lineHeight: '1.5' }}
        />
      </div>

      {/* Footer: Action Buttons */}
      <div className="p-4 border-t border-border space-y-3">
        <div className="grid grid-cols-3 gap-2">
          <Button
            onClick={handleRun}
            disabled={isRunning}
            variant="secondary"
            className="gap-2"
          >
            <Play className="w-4 h-4" />
            {isRunning ? 'Running...' : 'Run'}
          </Button>
          <Button
            onClick={handleDebug}
            variant="outline"
            className="gap-2 border-border"
          >
            <Bug className="w-4 h-4" />
            Debug
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isRunning}
            className="bg-primary hover:bg-primary/90 gap-2"
          >
            <Send className="w-4 h-4" />
            Submit
          </Button>
        </div>

        {/* Status Indicator */}
        <div className="text-xs text-foreground/60 text-center p-2 bg-background/50 rounded border border-border/50">
          Ready to submit • No syntax errors
        </div>
      </div>
    </div>
  );
}
