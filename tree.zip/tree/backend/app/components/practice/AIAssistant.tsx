'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp, Lightbulb, Zap, AlertCircle } from 'lucide-react';
import { MOCK_HINTS } from '@/lib/constants';

interface AIAssistantProps {
  problemId: string;
}

export function AIAssistant({ problemId }: AIAssistantProps) {
  const [expandedHints, setExpandedHints] = useState<number[]>([0]);
  const [activeTab, setActiveTab] = useState<'hints' | 'visualizer' | 'diagnostics'>('hints');

  const hints = MOCK_HINTS[problemId as keyof typeof MOCK_HINTS] || [];

  const toggleHint = (level: number) => {
    setExpandedHints(prev =>
      prev.includes(level)
        ? prev.filter(h => h !== level)
        : [...prev, level]
    );
  };

  return (
    <div className="h-full flex flex-col bg-card border-l border-border overflow-hidden">
      {/* Tab Navigation */}
      <div className="border-b border-border p-3 flex gap-2 flex-shrink-0">
        <Button
          variant={activeTab === 'hints' ? 'default' : 'ghost'}
          size="sm"
          className="gap-2"
          onClick={() => setActiveTab('hints')}
        >
          <Lightbulb className="w-4 h-4" />
          Hints
        </Button>
        <Button
          variant={activeTab === 'visualizer' ? 'default' : 'ghost'}
          size="sm"
          className="gap-2"
          onClick={() => setActiveTab('visualizer')}
        >
          <Zap className="w-4 h-4" />
          Visualizer
        </Button>
        <Button
          variant={activeTab === 'diagnostics' ? 'default' : 'ghost'}
          size="sm"
          className="gap-2"
          onClick={() => setActiveTab('diagnostics')}
        >
          <AlertCircle className="w-4 h-4" />
          Debug
        </Button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto min-h-0">
        {activeTab === 'hints' && (
          <div className="p-4 space-y-3">
            {hints.length > 0 ? (
              <>
                {hints.map((hint) => (
                  <Card
                    key={hint.level}
                    className="bg-background border-border hover:border-accent/50 transition-colors cursor-pointer"
                    onClick={() => toggleHint(hint.level)}
                  >
                    <div className="p-4 space-y-3">
                      {/* Header */}
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-xs font-bold px-2 py-1 rounded ${
                              hint.level === 1 ? 'bg-blue-500/20 text-blue-400' :
                              hint.level === 2 ? 'bg-purple-500/20 text-purple-400' :
                              'bg-orange-500/20 text-orange-400'
                            }`}>
                              Level {hint.level}
                            </span>
                            <span className="text-xs text-foreground/60 capitalize">{hint.category}</span>
                          </div>
                          <p className="text-sm font-bold text-foreground">
                            {hint.level === 1 && 'Conceptual Hint'}
                            {hint.level === 2 && 'Algorithm Hint'}
                            {hint.level === 3 && 'Edge Case Warning'}
                          </p>
                        </div>
                        {expandedHints.includes(hint.level) ? (
                          <ChevronUp className="w-5 h-5 text-foreground/60 flex-shrink-0" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-foreground/60 flex-shrink-0" />
                        )}
                      </div>

                      {/* Content - Only Show if Expanded and Unlocked */}
                      {expandedHints.includes(hint.level) && (
                        <div className={`text-sm leading-relaxed ${
                          hint.unlocked ? 'text-foreground/80' : 'text-foreground/60 italic'
                        }`}>
                          {hint.unlocked ? (
                            <p>{hint.content}</p>
                          ) : (
                            <p>Unlock this hint by reading the previous level</p>
                          )}
                        </div>
                      )}

                      {/* Action */}
                      {!expandedHints.includes(hint.level) && !hint.unlocked && (
                        <p className="text-xs text-foreground/50">Click to unlock</p>
                      )}
                    </div>
                  </Card>
                ))}
              </>
            ) : (
              <div className="text-center py-8 text-foreground/60">
                <p className="text-sm">No hints available for this problem yet</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'visualizer' && (
          <div className="p-4 space-y-4">
            <div className="h-32 bg-background border border-border rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Zap className="w-8 h-8 text-foreground/40 mx-auto mb-2" />
                <p className="text-sm text-foreground/60">Logic Visualizer</p>
                <p className="text-xs text-foreground/40 mt-1">Step through your algorithm</p>
              </div>
            </div>

            {/* Visualization Controls */}
            <Card className="p-3 bg-background border-border">
              <p className="text-xs text-foreground/60 mb-2">Execution State:</p>
              <div className="space-y-2">
                <div className="text-xs font-mono bg-background/50 p-2 rounded border border-border/50 text-foreground/70">
                  Step: 0 / 8<br/>
                  Variable sum: 0
                </div>
              </div>
            </Card>

            {/* Control Buttons */}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1">
                ⏮️ Reset
              </Button>
              <Button variant="outline" size="sm" className="flex-1">
                ⏯️ Play
              </Button>
              <Button variant="outline" size="sm" className="flex-1">
                ⏭️ Next
              </Button>
            </div>
          </div>
        )}

        {activeTab === 'diagnostics' && (
          <div className="p-4 space-y-4">
            <Card className="p-4 bg-red-500/10 border-red-500/30">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-red-400 text-sm mb-1">Wrong Answer</p>
                  <p className="text-xs text-foreground/70 leading-relaxed">
                    Test case 2 failed. Your output differs from expected. Check your logic for handling duplicate values.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-background border-border">
              <h4 className="text-sm font-bold text-foreground mb-3">Debugging Steps:</h4>
              <ol className="space-y-2 text-sm text-foreground/70">
                <li>1. Print the input to verify it's correct</li>
                <li>2. Add logs inside the loop to track variable changes</li>
                <li>3. Check if the condition logic is right</li>
                <li>4. Verify edge cases (empty, duplicates)</li>
              </ol>
            </Card>

            <Card className="p-3 bg-accent/5 border-accent/20">
              <p className="text-xs text-foreground/60">💡 Tip: Start with a simpler test case to debug faster</p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
