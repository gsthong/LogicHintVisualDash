'use client';

import { Problem } from '@/lib/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Copy, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

interface ProblemContextProps {
  problem: Problem;
}

export function ProblemContext({ problem }: ProblemContextProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const difficultyColor = {
    easy: 'bg-green-500/20 text-green-400 border-green-500/30',
    medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    hard: 'bg-red-500/20 text-red-400 border-red-500/30'
  };

  return (
    <div className="h-full w-full flex flex-col bg-card border-r border-border overflow-hidden">
      <Tabs defaultValue="description" className="flex-1 flex flex-col">
        <TabsList className="w-full rounded-none border-b border-border bg-transparent justify-start px-4">
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="syllabus">Syllabus Ref</TabsTrigger>
          <TabsTrigger value="samples">Test Cases</TabsTrigger>
        </TabsList>

        {/* Description Tab */}
        <TabsContent value="description" className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Header Info */}
          <div>
            <div className="flex items-start justify-between mb-3">
              <h1 className="text-xl font-bold text-foreground">{problem.title}</h1>
              <Badge className={`${difficultyColor[problem.difficulty]} border`}>
                {problem.difficulty.charAt(0).toUpperCase() + problem.difficulty.slice(1)}
              </Badge>
            </div>
            <div className="flex gap-2 mb-4">
              <Badge variant="secondary" className="bg-secondary/40 text-foreground">
                {problem.acceptance}% Acceptance
              </Badge>
              {problem.tags.map(tag => (
                <Badge key={tag} variant="outline" className="border-border">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-3">
            <h3 className="font-bold text-foreground">Problem Statement</h3>
            <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
              {problem.description}
            </p>
          </div>

          {/* Constraints */}
          {problem.constraints && (
            <div className="space-y-3">
              <h3 className="font-bold text-foreground">Constraints</h3>
              <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap font-mono bg-background/50 p-3 rounded border border-border">
                {problem.constraints}
              </p>
            </div>
          )}

          {/* Examples */}
          <div className="space-y-3">
            <h3 className="font-bold text-foreground">Examples</h3>
            {problem.examples.map((example, idx) => (
              <div key={idx} className="space-y-2 p-3 bg-background/50 rounded border border-border">
                <p className="text-xs font-medium text-foreground/60">Example {idx + 1}:</p>
                <div className="space-y-1">
                  <p className="text-xs text-foreground font-mono bg-background p-2 rounded border border-border/50">
                    Input: {example.input}
                  </p>
                  <p className="text-xs text-foreground font-mono bg-background p-2 rounded border border-border/50">
                    Output: {example.output}
                  </p>
                </div>
                {example.explanation && (
                  <p className="text-xs text-foreground/70">Explanation: {example.explanation}</p>
                )}
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Syllabus Reference Tab */}
        <TabsContent value="syllabus" className="flex-1 overflow-y-auto p-4">
          <div className="space-y-4">
            <h3 className="font-bold text-foreground">Related Topic</h3>
            {problem.syllabusTopic ? (
              <Card className="p-4 bg-accent/10 border-accent/30">
                <p className="text-sm font-medium text-foreground mb-2">{problem.syllabusTopic}</p>
                <p className="text-xs text-foreground/60">This problem covers concepts from this topic. Review the syllabus for more context.</p>
              </Card>
            ) : (
              <p className="text-sm text-foreground/60">No syllabus reference available</p>
            )}
          </div>
        </TabsContent>

        {/* Test Cases Tab */}
        <TabsContent value="samples" className="flex-1 overflow-y-auto p-4 space-y-3">
          <h3 className="font-bold text-foreground">Sample Test Cases</h3>
          {problem.examples.map((example, idx) => (
            <div key={idx} className="space-y-2 p-3 bg-background/50 rounded border border-border hover:border-border/80 transition-colors">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-foreground/60">Test {idx + 1}</p>
                <button
                  onClick={() => handleCopy(example.input, `test-${idx}`)}
                  className="flex items-center gap-1 px-2 py-1 text-xs rounded hover:bg-secondary transition-colors"
                >
                  {copiedId === `test-${idx}` ? (
                    <>
                      <CheckCircle2 className="w-3 h-3" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <code className="block text-xs bg-background p-2 rounded border border-border/50 font-mono overflow-x-auto text-foreground/80">
                {example.input}
              </code>
              <code className="block text-xs bg-background p-2 rounded border border-border/50 font-mono overflow-x-auto text-green-400">
                {example.output}
              </code>
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
