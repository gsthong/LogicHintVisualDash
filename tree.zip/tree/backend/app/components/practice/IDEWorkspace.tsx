'use client';

import { PanelGroup, Panel, PanelResizeHandle } from 'react-resizable-panels';
import { Problem } from '@/lib/types';
import { ProblemContext } from './ProblemContext';
import { CodeEditor } from './CodeEditor';
import { AIAssistant } from './AIAssistant';

interface IDEWorkspaceProps {
  problem: Problem;
}

export function IDEWorkspace({ problem }: IDEWorkspaceProps) {
  return (
    <div className="h-full w-full overflow-hidden">
      <PanelGroup direction="horizontal" className="h-full w-full">
        {/* Left Panel: Problem Description */}
        <Panel defaultSize={25} minSize={15} maxSize={40}>
          <ProblemContext problem={problem} />
        </Panel>

        {/* Resize Handle */}
        <PanelResizeHandle className="w-1 bg-border hover:bg-primary/30 transition-colors cursor-col-resize" />

        {/* Middle Panel: Code Editor */}
        <Panel defaultSize={50} minSize={25} maxSize={60}>
          <CodeEditor />
        </Panel>

        {/* Resize Handle */}
        <PanelResizeHandle className="w-1 bg-border hover:bg-primary/30 transition-colors cursor-col-resize" />

        {/* Right Panel: AI Assistant */}
        <Panel defaultSize={25} minSize={15} maxSize={40}>
          <AIAssistant problemId={problem.id} />
        </Panel>
      </PanelGroup>
    </div>
  );
}
