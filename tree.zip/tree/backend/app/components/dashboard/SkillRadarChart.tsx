'use client';

import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';
import { SkillData } from '@/lib/types';

interface SkillRadarChartProps {
  data: SkillData[];
}

export function SkillRadarChart({ data }: SkillRadarChartProps) {
  const chartData = data.map(skill => ({
    subject: skill.topic,
    A: skill.proficiency,
    fullMark: 100
  }));

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={chartData}>
          <PolarGrid 
            stroke="rgba(255, 255, 255, 0.1)"
            style={{ outline: 'none' }}
          />
          <PolarAngleAxis 
            dataKey="subject" 
            stroke="rgba(255, 255, 255, 0.6)"
            style={{ fontSize: '12px' }}
          />
          <PolarRadiusAxis
            stroke="rgba(255, 255, 255, 0.3)"
            style={{ fontSize: '11px' }}
          />
          <Radar
            name="Proficiency"
            dataKey="A"
            stroke="hsl(var(--color-primary))"
            fill="hsl(var(--color-primary))"
            fillOpacity={0.6}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
