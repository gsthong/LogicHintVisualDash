'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { difficulty: 'Easy', solved: 12, total: 12, fill: '#22c55e' },
  { difficulty: 'Medium', solved: 10, total: 15, fill: '#eab308' },
  { difficulty: 'Hard', solved: 2, total: 8, fill: '#ef4444' }
];

export function ProblemStatsChart() {
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <defs>
            <linearGradient id="colorSolved" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
            </linearGradient>
            <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--secondary))" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="hsl(var(--secondary))" stopOpacity={0.1}/>
            </linearGradient>
          </defs>
          <CartesianGrid 
            strokeDasharray="3 3" 
            stroke="rgba(255, 255, 255, 0.1)"
            style={{ outline: 'none' }}
          />
          <XAxis 
            dataKey="difficulty" 
            stroke="rgba(255, 255, 255, 0.6)"
            style={{ fontSize: '12px' }}
          />
          <YAxis
            stroke="rgba(255, 255, 255, 0.3)"
            style={{ fontSize: '11px' }}
          />
          <Tooltip
            cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
            contentStyle={{
              backgroundColor: 'hsl(var(--color-background))',
              border: '1px solid hsl(var(--color-border))',
              borderRadius: '8px',
              color: 'hsl(var(--color-foreground))'
            }}
          />
          <Legend />
          <Bar 
            dataKey="solved" 
            fill="url(#colorSolved)" 
            radius={[4, 4, 0, 0]} 
            barSize={30}
          />
          <Bar 
            dataKey="total" 
            fill="url(#colorTotal)" 
            radius={[4, 4, 0, 0]} 
            barSize={30}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
