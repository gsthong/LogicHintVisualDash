// Problem and Practice Types
export interface Example {
  input: string;
  output: string;
  explanation?: string;
}

export interface Problem {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  acceptance: number;
  tags: string[];
  examples: Example[];
  syllabusTopic?: string;
  constraints?: string;
}

export interface TestCase {
  id: string;
  input: string;
  expectedOutput: string;
  actualOutput?: string;
  status: 'pending' | 'passed' | 'failed' | 'runtime_error';
  notes?: string;
}

// AI Hint Types
export type HintLevel = 1 | 2 | 3;

export interface Hint {
  level: HintLevel;
  content: string;
  category: 'conceptual' | 'algorithm' | 'edge_case';
  unlocked: boolean;
}

// User and Progress Types
export interface UserStats {
  totalProblems: number;
  solvedProblems: number;
  streak: number;
  wecodeLastSync: Date | null;
  lastActive: Date;
}

export interface SkillData {
  topic: string;
  proficiency: number; // 0-100
  problemsSolved: number;
  averageTime: number; // in seconds
}

// Editor State
export interface EditorState {
  code: string;
  language: 'python' | 'cpp' | 'java' | 'javascript';
  theme: 'dark' | 'light';
}

// Submission Result
export interface SubmissionResult {
  status: 'accepted' | 'wrong_answer' | 'time_limit_exceeded' | 'runtime_error' | 'compilation_error';
  testsPassed: number;
  totalTests: number;
  runtime?: number;
  memory?: number;
  userComplexity?: {
    time: string;
    space: string;
  };
  optimalComplexity?: {
    time: string;
    space: string;
  };
}

// Syllabus
export interface SyllabusTopic {
  id: string;
  name: string;
  description?: string;
  subtopics?: string[];
  relatedProblems?: string[];
  progress: number;
}
