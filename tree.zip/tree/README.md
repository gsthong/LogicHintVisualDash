# CodeMentor - AI-Powered Programming Learning Platform

A comprehensive LeetCode-meets-ChatGPT style platform for learning programming with AI-powered hints, interactive IDE workspace, analytics, and Wecode integration.

## Features

### 🎯 Practice IDE Workspace
- **3-Column Resizable Layout**: Problem description, code editor, and AI assistant
- **Dark-Themed Code Editor**: Support for Python, C++, Java, and JavaScript
- **Real-Time Syntax Highlighting**: Code block formatting with line numbers
- **Multi-Tab Problem View**: Description, syllabus reference, and sample test cases

### 🤖 AI-Powered Assistant
- **Progressive Hint System**: 3-level hints (Conceptual, Algorithm, Edge Cases)
- **Logic Visualizer**: Step through algorithm execution
- **Error Diagnostics**: AI-powered debugging suggestions
- **Smart Problem Matching**: Links problems to syllabus topics

### 📊 Analytics Dashboard
- **Skill Radar Chart**: Track proficiency across 6 core topics
- **Problem Statistics**: Bar chart showing Easy/Medium/Hard progress
- **Exam Readiness Indicator**: Visual progress tracking with difficulty breakdown
- **Recent Activity Feed**: Track solved problems and achievements
- **Wecode Integration**: Sync submissions with one click

### 📚 Syllabus Management
- **Drag-Drop Upload**: Upload PDF or Word documents
- **Automatic Topic Extraction**: AI-powered syllabus parsing
- **Progress Tracking**: Per-topic practice metrics
- **Problem Mapping**: Automatic linking of problems to topics

### 🎓 Additional Features
- **Mock Exams**: Timed coding challenges with score tracking
- **User Settings**: Preferences, notifications, and account management
- **Streak System**: Motivational daily practice reminders
- **Success Modals**: Complexity comparison and optimization suggestions

## Project Structure

```
/vercel/share/v0-project/
├── app/
│   ├── layout.tsx (Root layout with dark theme)
│   ├── page.tsx (Home redirect)
│   ├── dashboard/page.tsx (Analytics & progress)
│   ├── practice/page.tsx (IDE workspace)
│   ├── mock-exams/page.tsx (Coding challenges)
│   ├── syllabus-upload/page.tsx (Upload & parse)
│   └── settings/page.tsx (User preferences)
├── components/
│   ├── layout/
│   │   ├── Sidebar.tsx (Navigation sidebar)
│   │   ├── TopBar.tsx (Header with sync status)
│   │   └── RootLayout.tsx (Main container)
│   ├── practice/
│   │   ├── IDEWorkspace.tsx (3-column layout)
│   │   ├── ProblemContext.tsx (Left: Problem)
│   │   ├── CodeEditor.tsx (Middle: Editor)
│   │   └── AIAssistant.tsx (Right: AI hints)
│   ├── dashboard/
│   │   ├── SkillRadarChart.tsx (Recharts radar)
│   │   ├── ProblemStatsChart.tsx (Recharts bar)
│   │   ├── ExamReadinessIndicator.tsx (Progress)
│   │   ├── WecodeSync.tsx (Sync button)
│   │   ├── SuccessModal.tsx (Completion modal)
│   │   └── RecentActivityFeed.tsx (Activity list)
│   └── ui/ (shadcn/ui components)
├── lib/
│   ├── types.ts (TypeScript interfaces)
│   ├── constants.ts (Mock data)
│   └── utils.ts (Utility functions)
└── app/globals.css (Dark theme & animations)
```

## Technology Stack

- **Framework**: Next.js 14 with App Router
- **UI**: shadcn/ui components
- **Styling**: Tailwind CSS v4 with dark theme
- **Charts**: Recharts (Radar & Bar charts)
- **Layout**: react-resizable-panels (3-column IDE)
- **Icons**: Lucide-react
- **Notifications**: Sonner toasts
- **Forms**: react-hook-form with Zod
- **Theme**: Dark mode by default

## Color System

Professional dark theme optimized for coding:
- **Background**: oklch(0.11 0 0) - Deep dark
- **Primary**: oklch(0.55 0.3 280) - Purple accent
- **Secondary**: oklch(0.25 0 0) - Dark gray
- **Accent**: oklch(0.6 0.3 280) - Bright purple
- **Chart Colors**: Purple, blue, teal, orange, cyan variants

## Key Components

### Sidebar Navigation
- Dashboard, Practice, Mock Exams, Syllabus Upload, Settings
- Current streak and problems solved badges
- Active state highlighting with accent color

### IDE Workspace
- Problem description with difficulty and acceptance rates
- 3-column resizable layout with smooth transitions
- Code editor with language selector
- AI Assistant with expandable hints

### Dashboard
- Radar chart for skill proficiency visualization
- Bar chart for solved vs total problems by difficulty
- Exam readiness progress indicator
- Recent activity feed with icons and timestamps
- Wecode sync integration

## Getting Started

1. **Install Dependencies**:
   ```bash
   pnpm install
   ```

2. **Run Development Server**:
   ```bash
   pnpm dev
   ```

3. **Open Browser**:
   ```
   http://localhost:3000
   ```

## Features Implemented

### Phase 1: Foundation ✓
- Root layout with dark theme
- Providers setup (dark mode, toaster)
- Global styling and animations

### Phase 2: Navigation ✓
- Sidebar with active states
- Top bar with user menu
- Layout wrapper component

### Phase 3: IDE Workspace ✓
- 3-column resizable layout
- Problem context with tabs
- Code editor with language selector
- AI assistant with progressive hints

### Phase 4: Dashboard ✓
- Skill radar chart
- Problem statistics chart
- Exam readiness indicator
- Activity feed
- Wecode sync button

### Phase 5: Syllabus ✓
- Drag-drop upload zone
- Topic extraction display
- Progress tracking per topic

### Phase 6: Polish ✓
- Smooth animations and transitions
- Success modals with complexity comparison
- Mock exams interface
- Settings page

## Mock Data

The platform includes comprehensive mock data:
- **3 Sample Problems**: Two Sum, Median of Arrays, Longest Substring
- **6 Skill Topics**: Arrays, Binary Search, Trees, DP, Graphs, Strings
- **6 Syllabus Topics**: Auto-generated with subtopics and progress
- **Progressive Hints**: 3-level hints with unlock logic
- **User Stats**: Streak, solved problems, test results

## Customization

### Adding New Problems
Edit `lib/constants.ts` and add to `MOCK_PROBLEMS` array

### Changing Colors
Modify design tokens in `app/globals.css` CSS variables

### Adding Languages
Update `CODE_TEMPLATES` and `LANGUAGES` in `lib/constants.ts`

### Styling Components
All components use Tailwind CSS classes with design tokens for consistency

## Browser Support

- Chrome/Edge (Latest)
- Firefox (Latest)
- Safari (Latest)
- Requires JavaScript enabled

## Future Enhancements

- Backend API integration
- Real user authentication
- Database persistence
- Actual Wecode API integration
- More advanced code editor (Monaco)
- Video tutorials integration
- Community discussions
- Peer code review

---

Built with Next.js 14, Tailwind CSS, and shadcn/ui. Dark mode optimized for an immersive coding experience.